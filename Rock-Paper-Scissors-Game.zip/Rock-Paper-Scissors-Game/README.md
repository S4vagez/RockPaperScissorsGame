# Rock Paper Scissors Game

A new Flutter project.

This project has three pages: Login Page, Game Page and a Score Board. In the Login Page the user should provide username, choose color of preference, and how many attempts should one wants to play. 

In the Game Page the actual process starts and the user play the game with the computer.

The result of the game will be shown in the tab in the Score Board Page.




