import 'package:flutter/material.dart';

class User {
  String? username;
  Color? color;
  int? gameLength;

  User(this.username, this.color, this.gameLength);
}